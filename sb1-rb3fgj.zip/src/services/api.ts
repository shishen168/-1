import { smsService } from './smsService';
import { contactsService } from './contactsService';
import { Contact } from '../types';

export interface SMSRecord {
  id: string;
  recipient: string;
  message: string;
  status: 'sent' | 'failed' | 'scheduled';
  sendTime: string;
  isIncoming?: boolean;
}

export const smsAPI = {
  sendSMS: smsService.sendSMS.bind(smsService),
  getDeliveryStatus: smsService.getDeliveryStatus.bind(smsService),
  
  getLocalHistory: (): SMSRecord[] => {
    try {
      const saved = localStorage.getItem('sms_history');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Error loading SMS history:', error);
      return [];
    }
  },

  deleteMessage: (messageId: string): { success: boolean; message?: string } => {
    try {
      const history = smsAPI.getLocalHistory();
      const filtered = history.filter(msg => msg.id !== messageId);
      localStorage.setItem('sms_history', JSON.stringify(filtered));
      return { success: true };
    } catch (error) {
      return { success: false, message: '删除消息失败' };
    }
  },

  deleteThread: (recipient: string): { success: boolean; message?: string } => {
    try {
      const history = smsAPI.getLocalHistory();
      const filtered = history.filter(msg => msg.recipient !== recipient);
      localStorage.setItem('sms_history', JSON.stringify(filtered));
      return { success: true };
    } catch (error) {
      return { success: false, message: '删除对话失败' };
    }
  },

  isPinned: (recipient: string): boolean => {
    try {
      const pinned = localStorage.getItem('pinned_threads');
      const pinnedThreads = pinned ? JSON.parse(pinned) : [];
      return pinnedThreads.includes(recipient);
    } catch (error) {
      return false;
    }
  },

  togglePin: (recipient: string): void => {
    try {
      const pinned = localStorage.getItem('pinned_threads');
      const pinnedThreads = pinned ? JSON.parse(pinned) : [];
      const index = pinnedThreads.indexOf(recipient);
      
      if (index === -1) {
        pinnedThreads.push(recipient);
      } else {
        pinnedThreads.splice(index, 1);
      }
      
      localStorage.setItem('pinned_threads', JSON.stringify(pinnedThreads));
    } catch (error) {
      console.error('Error toggling pin:', error);
    }
  }
};

export const contactsAPI = {
  getContacts: async () => {
    try {
      const contacts = contactsService.getContacts();
      return {
        success: true,
        data: contacts
      };
    } catch (error) {
      return {
        success: false,
        message: '获取联系人失败'
      };
    }
  },

  addContact: async (contact: Omit<Contact, 'id'>) => {
    try {
      const newContact = contactsService.addContact(contact);
      return {
        success: true,
        data: newContact
      };
    } catch (error) {
      return {
        success: false,
        message: '添加联系人失败'
      };
    }
  },

  updateContact: async (id: string, contact: Partial<Contact>) => {
    try {
      const success = contactsService.updateContact(id, contact);
      return {
        success,
        message: success ? '更新成功' : '更新失败'
      };
    } catch (error) {
      return {
        success: false,
        message: '更新联系人失败'
      };
    }
  },

  deleteContact: async (id: string) => {
    try {
      const success = contactsService.deleteContact(id);
      return {
        success,
        message: success ? '删除成功' : '删除失败'
      };
    } catch (error) {
      return {
        success: false,
        message: '删除联系人失败'
      };
    }
  }
};