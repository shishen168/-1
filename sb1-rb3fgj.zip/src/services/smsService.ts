import axios from 'axios';
import { userService } from './userService';
import { blacklistService } from './blacklistService';
import { priceService } from './priceService';

interface SendSMSParams {
  recipients: string[];
  message: string;
  scheduleTime?: string;
}

interface SMSResponse {
  success: boolean;
  message?: string;
  data?: any;
}

class SMSService {
  private readonly API_ENDPOINT = 'https://api.textinghouse.com/http/v1/do';
  private readonly API_USER = 'afei4913@gmail.com';
  private readonly API_PASS = '3jrnig3ks38r00j4rhb5pvg2';

  async sendSMS({ recipients, message, scheduleTime }: SendSMSParams): Promise<SMSResponse> {
    try {
      // Get current user
      const currentUser = userService.getCurrentUser();
      if (!currentUser) {
        return {
          success: false,
          message: '用户未登录'
        };
      }

      // Validate recipients
      const validRecipients = recipients.filter(phone => {
        if (blacklistService.isBlacklisted(phone)) {
          return false;
        }
        return true;
      });

      if (validRecipients.length === 0) {
        return {
          success: false,
          message: '没有有效的收件人'
        };
      }

      // Calculate total cost
      const prices = priceService.getSettings();
      const totalCost = validRecipients.length * prices.sendPrice;

      // Check user balance
      const userData = userService.getUserById(currentUser.id);
      if (!userData || userData.balance < totalCost) {
        return {
          success: false,
          message: '余额不足，请充值'
        };
      }

      // Send SMS to each recipient
      const results = await Promise.all(
        validRecipients.map(async (recipient) => {
          try {
            const response = await axios.get(this.API_ENDPOINT, {
              params: {
                user: this.API_USER,
                pass: this.API_PASS,
                cmd: 'sendsms',
                to: recipient.replace(/^\+/, ''),
                txt: encodeURIComponent(message),
                iscom: 'N',
                climsgid: Date.now().toString()
              }
            });

            if (response.data.startsWith('ID:')) {
              const messageId = response.data.substring(3);
              return {
                recipient,
                success: true,
                messageId
              };
            } else {
              return {
                recipient,
                success: false,
                error: response.data.startsWith('ERR:') ? response.data.substring(5) : '发送失败'
              };
            }
          } catch (error) {
            return {
              recipient,
              success: false,
              error: error instanceof Error ? error.message : '发送失败'
            };
          }
        })
      );

      // Calculate successful sends
      const successfulSends = results.filter(r => r.success);
      const totalSuccess = successfulSends.length;
      const totalFailed = results.length - totalSuccess;

      // Deduct balance for successful sends only
      if (totalSuccess > 0) {
        const actualCost = totalSuccess * prices.sendPrice;
        userService.deductBalance(currentUser.id, actualCost);

        // Save to local history
        this.saveMessageHistory({
          recipients: successfulSends.map(r => r.recipient),
          message,
          status: 'sent',
          sendTime: new Date().toISOString()
        });
      }

      if (totalSuccess === 0) {
        return {
          success: false,
          message: '所有短信发送失败',
          data: results
        };
      }

      return {
        success: true,
        message: totalFailed > 0 
          ? `成功发送 ${totalSuccess} 条短信，失败 ${totalFailed} 条`
          : `成功发送 ${totalSuccess} 条短信`,
        data: results
      };

    } catch (error) {
      console.error('SMS sending error:', error);
      return {
        success: false,
        message: error instanceof Error ? error.message : '发送失败'
      };
    }
  }

  private saveMessageHistory(data: {
    recipients: string[];
    message: string;
    status: string;
    sendTime: string;
  }) {
    try {
      const history = JSON.parse(localStorage.getItem('sms_history') || '[]');
      const newRecords = data.recipients.map(recipient => ({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        recipient,
        message: data.message,
        status: data.status,
        sendTime: data.sendTime
      }));

      history.push(...newRecords);
      localStorage.setItem('sms_history', JSON.stringify(history));
      window.dispatchEvent(new Event('smsHistoryUpdate'));
    } catch (error) {
      console.error('Error saving SMS history:', error);
    }
  }

  getLocalHistory(): any[] {
    try {
      const saved = localStorage.getItem('sms_history');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('Error loading SMS history:', error);
      return [];
    }
  }

  async getDeliveryStatus(messageId: string): Promise<SMSResponse> {
    try {
      const response = await axios.get(this.API_ENDPOINT, {
        params: {
          user: this.API_USER,
          pass: this.API_PASS,
          cmd: 'getstatus',
          api_id: messageId
        }
      });

      const status = response.data;
      const statusMap: { [key: string]: string } = {
        '0': '处理中',
        '1': '等待状态',
        '3': '已送达',
        '4': '已过期',
        '5': '未订阅',
        '6': '无法送达',
        '7': '发送失败',
        '20': '余额不足'
      };

      return {
        success: true,
        message: statusMap[status] || '未知状态',
        data: {
          status,
          description: statusMap[status]
        }
      };
    } catch (error) {
      console.error('Error getting delivery status:', error);
      return {
        success: false,
        message: '获取发送状态失败'
      };
    }
  }
}

export const smsService = new SMSService();